/**
 * Entry Point to the system
 */

const ignite = require("./loaders");

ignite();
