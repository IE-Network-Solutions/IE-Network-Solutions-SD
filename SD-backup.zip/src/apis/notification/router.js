const router = require("express").Router();
const NotificationController = require("./controller");

router
    .route("/newbrowser")
    .post( NotificationController.newBrowser);

router
    .route("/notify")
    .post( NotificationController.notify);

module.exports = router;